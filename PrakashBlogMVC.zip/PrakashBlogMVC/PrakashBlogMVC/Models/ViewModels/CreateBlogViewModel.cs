﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PrakashBlogMVC.Models.ViewModels
{
    public class CreateBlogViewModel
    {
        public CreateBlogViewModel(Blog blog, List<Category> categories)
        {
            Blog = blog;
            Categories = new SelectList(categories.ToList(), "ID", "CategoryName");
        }

        public Blog Blog { get; private set; }
        public SelectList Categories { get; private set; }
    }
}