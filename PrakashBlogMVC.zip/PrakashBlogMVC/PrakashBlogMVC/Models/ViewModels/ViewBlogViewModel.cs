﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PrakashBlogMVC.Models.ViewModels
{
    public class ViewBlogViewModel
    {
        public ViewBlogViewModel(Blog blog, List<Comment> comments, string categoryName)
        {
            this.Blog = blog;
            Comments = comments;
            CategoryName = categoryName;
        }

        public Blog Blog { get; private set; }
        
        public List<Comment> Comments { get; private set; }
        
        public string CategoryName {get; private set;}
        
        public int CommentCount 
        {
            get
            {
                return Comments.Count;
            }
        }
    }
}