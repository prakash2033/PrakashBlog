﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace PrakashBlogMVC.Models
{
    [MetadataType(typeof(CommentMetaData))]
    public partial class Comment
    {

    }

    public class CommentMetaData
    {
        [Required(ErrorMessage = "Comment contents required before posting")]
        public string Comment1 { get; set; }
    }
}