﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PrakashBlogMVC.Models
{
    public class CommentsRepository : ICommentsRepository
    {
        PrakashBlogDbEntities entities = null;

        public CommentsRepository(PrakashBlogDbEntities entities)
        {
            this.entities = entities;
        }

        public List<Comment> GetCommentsByBlogId(int id)
        {
            return entities.Comments.Where(c => c.BlogId == id).ToList();
        }

        public void Save()
        {
            entities.SaveChanges();
        }
    }
}