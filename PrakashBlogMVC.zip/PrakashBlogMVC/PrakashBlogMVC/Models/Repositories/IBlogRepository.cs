﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PrakashBlogMVC.Models.ViewModels;

namespace PrakashBlogMVC.Models
{
    public interface IBlogRepository
    {
        void AddBlog(Blog blog);
        Blog GetBlogById(int id);
        IQueryable<Blog> GetBlogs(int categoryId);
        List<CategoryListViewModel> GetActiveCategories();
        void RemoveBlog(Blog blog);
        void Save();

        
    }
}