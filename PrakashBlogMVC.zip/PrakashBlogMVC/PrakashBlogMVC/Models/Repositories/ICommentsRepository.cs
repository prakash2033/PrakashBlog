﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PrakashBlogMVC.Models
{
    public interface ICommentsRepository
    {
        List<Comment> GetCommentsByBlogId(int id);
        void Save();
    }
}