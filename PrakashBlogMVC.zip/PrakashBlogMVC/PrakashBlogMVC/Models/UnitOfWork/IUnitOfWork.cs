﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PrakashBlogMVC.Models
{
    public interface IUnitOfWork
    {
       ICategoryRepository CategoryRepo {get; }
       IBlogRepository BlogRepo { get; }
       ICommentsRepository CommentsRepo { get; }
    }
}